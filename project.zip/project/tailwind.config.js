/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f7ff',
          100: '#dcedfd',
          200: '#c0ddfb',
          300: '#93c5f8',
          400: '#60a5f2',
          500: '#3d84e6',
          600: '#2563eb',
          700: '#1d58d8',
          800: '#1e48af',
          900: '#1e3f8a',
          950: '#172654',
        },
        secondary: {
          50: '#effcf6',
          100: '#dafaec',
          200: '#b5f2d3',
          300: '#7fe8b7',
          400: '#45d595',
          500: '#1dbf73',
          600: '#12a972',
          700: '#117a56',
          800: '#125d44',
          900: '#124d39',
          950: '#072b20',
        },
        accent: {
          50: '#fff7ed',
          100: '#ffeed3',
          200: '#ffdba7',
          300: '#ffc06d',
          400: '#ff9835',
          500: '#f97316',
          600: '#ea580c',
          700: '#c2410c',
          800: '#9a3412',
          900: '#7c2d12',
          950: '#431407',
        }
      }
    },
  },
  plugins: [],
};