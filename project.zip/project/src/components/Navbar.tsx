import React from 'react';
import { NavLink } from 'react-router-dom';

interface NavbarProps {
  mobile?: boolean;
  onItemClick?: () => void;
}

function Navbar({ mobile = false, onItemClick }: NavbarProps) {
  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Events', path: '/events' },
    { name: 'Artifacts', path: '/artifacts' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'News', path: '/news' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];

  const baseStyles = mobile 
    ? "block py-2 text-lg" 
    : "px-4 py-2 text-base";
    
  const activeStyles = "font-medium text-primary-600";
  const inactiveStyles = "text-gray-700 hover:text-primary-500 transition-colors duration-200";

  return (
    <ul className={mobile ? "space-y-2" : "flex space-x-1"}>
      {navItems.map((item) => (
        <li key={item.name}>
          <NavLink
            to={item.path}
            className={({ isActive }) => 
              `${baseStyles} ${isActive ? activeStyles : inactiveStyles}`
            }
            onClick={onItemClick}
            end
          >
            {item.name}
          </NavLink>
        </li>
      ))}
      <li>
        <NavLink
          to="/admin"
          className={({ isActive }) => 
            `${baseStyles} ${isActive ? activeStyles : inactiveStyles} ${mobile ? '' : 'ml-4'} border border-accent-500 text-accent-500 hover:bg-accent-500 hover:text-white rounded-md transition-colors duration-200`
          }
          onClick={onItemClick}
        >
          Admin
        </NavLink>
      </li>
    </ul>
  );
}

export default Navbar;