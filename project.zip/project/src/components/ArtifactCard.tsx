import React from 'react';
import { Info, History, ArrowRight } from 'lucide-react';

interface ArtifactCardProps {
  title: string;
  description: string;
  origin: string;
  period: string;
  imageSrc: string;
}

function ArtifactCard({ 
  title, 
  description, 
  origin, 
  period, 
  imageSrc 
}: ArtifactCardProps) {
  
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-100">
      <div className="h-56 overflow-hidden bg-gray-100">
        <img 
          src={imageSrc} 
          alt={title} 
          className="w-full h-full object-contain transition-transform duration-300 hover:scale-105"
        />
      </div>
      
      <div className="p-5">
        <h3 className="text-lg font-semibold mb-2 text-gray-800">{title}</h3>
        <p className="text-gray-600 mb-4 text-sm line-clamp-2">{description}</p>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-gray-600 text-sm">
            <Info size={16} className="mr-2 text-secondary-500" />
            <span><span className="font-medium">Origin:</span> {origin}</span>
          </div>
          
          <div className="flex items-center text-gray-600 text-sm">
            <History size={16} className="mr-2 text-secondary-500" />
            <span><span className="font-medium">Period:</span> {period}</span>
          </div>
        </div>
        
        <button className="inline-flex items-center text-primary-600 hover:text-primary-800 transition-colors duration-200">
          <span className="mr-1">View Details</span>
          <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

export default ArtifactCard;