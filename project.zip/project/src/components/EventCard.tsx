import React from 'react';
import { Calendar, Clock, MapPin } from 'lucide-react';

interface EventCardProps {
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  imageSrc: string;
  featured?: boolean;
}

function EventCard({ 
  title, 
  description, 
  date, 
  time, 
  location, 
  imageSrc, 
  featured = false 
}: EventCardProps) {
  
  return (
    <div className={`
      bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300
      ${featured ? 'border-l-4 border-accent-500' : ''}
    `}>
      <div className="h-48 overflow-hidden">
        <img 
          src={imageSrc} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      
      <div className="p-5">
        {featured && (
          <span className="inline-block px-3 py-1 text-xs font-medium text-white bg-accent-500 rounded-full mb-3">
            Featured
          </span>
        )}
        
        <h3 className="text-xl font-semibold mb-2 text-gray-800">{title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-2">{description}</p>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-gray-600">
            <Calendar size={16} className="mr-2 text-primary-500" />
            <span>{date}</span>
          </div>
          
          <div className="flex items-center text-gray-600">
            <Clock size={16} className="mr-2 text-primary-500" />
            <span>{time}</span>
          </div>
          
          <div className="flex items-center text-gray-600">
            <MapPin size={16} className="mr-2 text-primary-500" />
            <span>{location}</span>
          </div>
        </div>
        
        <button className="inline-block px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors duration-200">
          View Details
        </button>
      </div>
    </div>
  );
}

export default EventCard;