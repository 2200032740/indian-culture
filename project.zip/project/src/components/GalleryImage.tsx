import React, { useState } from 'react';
import { X, ZoomIn } from 'lucide-react';

interface GalleryImageProps {
  src: string;
  alt: string;
  category: string;
}

function GalleryImage({ src, alt, category }: GalleryImageProps) {
  const [showModal, setShowModal] = useState(false);
  
  return (
    <>
      <div 
        className="relative group overflow-hidden rounded-lg cursor-pointer"
        onClick={() => setShowModal(true)}
      >
        <img 
          src={src} 
          alt={alt} 
          className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <ZoomIn className="text-white" size={28} />
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
          <span className="text-white font-medium text-sm">{alt}</span>
          <span className="absolute top-3 right-3 bg-primary-500 text-white text-xs px-2 py-1 rounded-full">
            {category}
          </span>
        </div>
      </div>
      
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-90 p-4">
          <button 
            className="absolute top-4 right-4 text-white hover:text-gray-300"
            onClick={() => setShowModal(false)}
          >
            <X size={32} />
          </button>
          <div className="max-w-4xl max-h-[90vh]">
            <img 
              src={src} 
              alt={alt} 
              className="max-w-full max-h-[85vh] object-contain"
            />
            <div className="mt-4 text-white">
              <h3 className="text-xl font-medium">{alt}</h3>
              <p className="text-gray-300">Category: {category}</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default GalleryImage;