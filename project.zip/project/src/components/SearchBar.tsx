import React, { useState } from 'react';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  placeholder?: string;
  categories?: string[];
  onSearch?: (query: string, category: string) => void;
}

function SearchBar({ 
  placeholder = "Search...", 
  categories = [],
  onSearch = () => {} 
}: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query, selectedCategory);
  };
  
  const clearSearch = () => {
    setQuery('');
    onSearch('', selectedCategory);
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={20} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder={placeholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {query && (
            <button
              type="button"
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
              onClick={clearSearch}
            >
              <X size={18} className="text-gray-400 hover:text-gray-600" />
            </button>
          )}
        </div>
        
        {categories.length > 0 && (
          <select
            className="py-2 px-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500 md:w-1/5"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="all">All Categories</option>
            {categories.map((category) => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        )}
        
        <button
          type="submit"
          className="py-2 px-6 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors duration-200 md:w-auto"
        >
          Search
        </button>
      </form>
    </div>
  );
}

export default SearchBar;