import React from 'react';

interface HeroSectionProps {
  title: string;
  subtitle?: string;
  imageSrc: string;
  overlay?: boolean;
  height?: 'sm' | 'md' | 'lg' | 'xl';
  children?: React.ReactNode;
}

function HeroSection({ 
  title, 
  subtitle, 
  imageSrc, 
  overlay = true, 
  height = 'lg',
  children 
}: HeroSectionProps) {
  
  const heightClasses = {
    sm: 'h-64',
    md: 'h-80',
    lg: 'h-96',
    xl: 'h-[32rem]'
  };
  
  return (
    <div 
      className={`relative ${heightClasses[height]} w-full bg-cover bg-center flex items-center justify-center`}
      style={{ backgroundImage: `url(${imageSrc})` }}
    >
      {overlay && (
        <div className="absolute inset-0 bg-gradient-to-r from-primary-900/70 to-secondary-900/70"></div>
      )}
      
      <div className="relative z-10 text-center text-white px-4 md:px-8 max-w-4xl">
        <h1 className="text-3xl md:text-5xl font-bold mb-4 drop-shadow-md">{title}</h1>
        {subtitle && (
          <p className="text-lg md:text-xl mb-6 max-w-3xl mx-auto drop-shadow-md">{subtitle}</p>
        )}
        {children}
      </div>
    </div>
  );
}

export default HeroSection;