import React from 'react';
import { Calendar, User } from 'lucide-react';

interface NewsCardProps {
  title: string;
  summary: string;
  date: string;
  author: string;
  imageSrc: string;
  featured?: boolean;
}

function NewsCard({ 
  title, 
  summary, 
  date, 
  author, 
  imageSrc, 
  featured = false 
}: NewsCardProps) {
  
  return (
    <div className={`
      bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 h-full
      ${featured ? 'md:col-span-2 md:flex' : ''}
    `}>
      <div className={`${featured ? 'md:w-1/2 h-64 md:h-auto' : 'h-48'} overflow-hidden`}>
        <img 
          src={imageSrc} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      
      <div className={`p-5 ${featured ? 'md:w-1/2' : ''}`}>
        {featured && (
          <span className="inline-block px-3 py-1 text-xs font-medium text-white bg-secondary-600 rounded-full mb-3">
            Featured
          </span>
        )}
        
        <h3 className={`${featured ? 'text-2xl' : 'text-xl'} font-semibold mb-2 text-gray-800 line-clamp-2`}>
          {title}
        </h3>
        
        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
          <div className="flex items-center">
            <Calendar size={14} className="mr-1 text-primary-500" />
            <span>{date}</span>
          </div>
          
          <div className="flex items-center">
            <User size={14} className="mr-1 text-primary-500" />
            <span>{author}</span>
          </div>
        </div>
        
        <p className={`text-gray-600 ${featured ? 'mb-6' : 'mb-4'} ${featured ? '' : 'line-clamp-3'}`}>
          {summary}
        </p>
        
        <button className="inline-block px-4 py-2 bg-white text-primary-600 border border-primary-600 rounded-md hover:bg-primary-50 transition-colors duration-200">
          Read More
        </button>
      </div>
    </div>
  );
}

export default NewsCard;