import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Calendar, 
  ArchiveRestore,
  ImageIcon, 
  Newspaper, 
  MessageSquare,
  Settings,
  LogOut
} from 'lucide-react';

interface AdminSidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

function AdminSidebar({ isOpen, toggleSidebar }: AdminSidebarProps) {
  const menuItems = [
    { icon: <LayoutDashboard size={20} />, name: 'Dashboard', path: '/admin' },
    { icon: <Calendar size={20} />, name: 'Events', path: '/admin/events' },
    { icon: <ArchiveRestore size={20} />, name: 'Artifacts', path: '/admin/artifacts' },
    { icon: <ImageIcon size={20} />, name: 'Gallery', path: '/admin/gallery' },
    { icon: <Newspaper size={20} />, name: 'News', path: '/admin/news' },
    { icon: <MessageSquare size={20} />, name: 'Messages', path: '/admin/messages' },
    { icon: <Settings size={20} />, name: 'Settings', path: '/admin/settings' },
  ];
  
  return (
    <aside 
      className={`
        fixed top-0 left-0 h-full bg-gray-800 text-white transition-all duration-300 ease-in-out z-40
        ${isOpen ? 'w-64' : 'w-20'}
        min-h-screen
      `}
    >
      <div className="p-4 flex items-center justify-center h-16 border-b border-gray-700">
        {isOpen ? (
          <h2 className="text-xl font-bold">Admin Panel</h2>
        ) : (
          <h2 className="text-xl font-bold">AP</h2>
        )}
      </div>
      
      <nav className="mt-6">
        <ul>
          {menuItems.map((item) => (
            <li key={item.name} className="mb-2">
              <NavLink
                to={item.path}
                className={({ isActive }) => `
                  flex items-center px-4 py-3 transition-colors duration-200
                  ${isActive ? 'bg-primary-700 text-white' : 'text-gray-300 hover:bg-gray-700'} 
                `}
                end
              >
                <span className={`${isOpen ? 'mr-4' : 'mx-auto'}`}>{item.icon}</span>
                {isOpen && <span>{item.name}</span>}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <button className={`
          flex items-center text-red-300 hover:text-red-400 transition-colors duration-200
          ${isOpen ? 'px-4 py-3 w-full' : 'justify-center px-0 py-3 w-full'}
        `}>
          <LogOut size={20} className={isOpen ? 'mr-4' : 'mx-auto'} />
          {isOpen && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}

export default AdminSidebar;