// Event Types
export interface Event {
  id: number;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  imageSrc: string;
  featured?: boolean;
  category?: string;
}

// Artifact Types
export interface Artifact {
  id: number;
  title: string;
  description: string;
  origin: string;
  period: string;
  imageSrc: string;
  category?: string;
}

// Gallery Types
export interface GalleryItem {
  id: number;
  src: string;
  alt: string;
  category: string;
}

// News Types
export interface NewsItem {
  id: number;
  title: string;
  summary: string;
  date: string;
  author: string;
  imageSrc: string;
  featured?: boolean;
  category?: string;
}

// Team Member Types
export interface TeamMember {
  name: string;
  position: string;
  bio: string;
  imageSrc: string;
}

// Contact Form Types
export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

// Admin Types
export interface AdminActivity {
  id: number;
  action: string;
  item: string;
  user: string;
  time: string;
}

export interface Stat {
  name: string;
  value: string | number;
  icon: React.ReactNode;
}