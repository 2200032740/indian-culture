import React, { useState } from 'react';
import { Bar, BarChart, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { AlignJustify, X, Users, Calendar, ArchiveRestore, ImageIcon, Newspaper, MessageSquare } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';

function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  // Sample data
  const eventStats = [
    { name: 'Jan', count: 4 },
    { name: 'Feb', count: 6 },
    { name: 'Mar', count: 8 },
    { name: 'Apr', count: 10 },
    { name: 'May', count: 7 },
    { name: 'Jun', count: 9 },
    { name: 'Jul', count: 12 },
    { name: 'Aug', count: 15 },
    { name: 'Sep', count: 10 },
    { name: 'Oct', count: 8 },
    { name: 'Nov', count: 5 },
    { name: 'Dec', count: 7 },
  ];
  
  const recentActivities = [
    { id: 1, action: "Added new event", item: "Classical Dance Festival", user: "Amit Patel", time: "2 hours ago" },
    { id: 2, action: "Updated artifact", item: "Bronze Nataraja Statue", user: "Priya Sharma", time: "5 hours ago" },
    { id: 3, action: "Uploaded gallery images", item: "Holi Festival 2025", user: "Rajesh Kumar", time: "Yesterday" },
    { id: 4, action: "Published news article", item: "New Cultural Initiative", user: "Meera Singh", time: "2 days ago" },
    { id: 5, action: "Responded to message", item: "School Visit Inquiry", user: "Lakshmi Nair", time: "3 days ago" },
  ];
  
  const stats = [
    { name: "Total Events", value: 124, icon: <Calendar size={24} className="text-primary-500" /> },
    { name: "Artifacts", value: 432, icon: <ArchiveRestore size={24} className="text-secondary-500" /> },
    { name: "Gallery Items", value: 856, icon: <ImageIcon size={24} className="text-accent-500" /> },
    { name: "News Articles", value: 78, icon: <Newspaper size={24} className="text-green-500" /> },
    { name: "User Messages", value: 45, icon: <MessageSquare size={24} className="text-yellow-500" /> },
    { name: "Visitors", value: "12.5K", icon: <Users size={24} className="text-purple-500" /> },
  ];
  
  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <AdminSidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      
      {/* Main Content */}
      <div className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <header className="bg-white shadow-sm h-16 flex items-center justify-between px-6">
          <button 
            onClick={toggleSidebar}
            className="p-2 rounded-md text-gray-600 hover:bg-gray-100"
          >
            {sidebarOpen ? <X size={20} /> : <AlignJustify size={20} />}
          </button>
          
          <div className="flex items-center space-x-4">
            <div className="relative">
              <span className="sr-only">Notifications</span>
              <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">
                3
              </span>
              <button className="p-2 rounded-md text-gray-600 hover:bg-gray-100">
                <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
              </button>
            </div>
            
            <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Profile"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </header>
        
        <main className="p-6">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-800 mb-1">Dashboard</h1>
            <p className="text-gray-600">Welcome back, Dr. Rajesh Kumar!</p>
          </div>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {stats.map((stat, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-gray-50 rounded-full p-3">
                    {stat.icon}
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-gray-800">{stat.value}</h2>
                    <p className="text-gray-600 text-sm">{stat.name}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Charts & Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4 text-gray-800">Events (Last 12 Months)</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={eventStats}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#4F46E5" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4 text-gray-800">Recent Activities</h2>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="border-b border-gray-100 pb-3 last:border-b-0 last:pb-0">
                    <div className="flex justify-between mb-1">
                      <span className="font-medium text-gray-800">{activity.action}</span>
                      <span className="text-sm text-gray-500">{activity.time}</span>
                    </div>
                    <div className="text-sm text-gray-600">{activity.item}</div>
                    <div className="text-xs text-gray-500">by {activity.user}</div>
                  </div>
                ))}
              </div>
              <button className="mt-4 w-full py-2 bg-gray-50 text-primary-600 hover:bg-gray-100 rounded-md text-sm transition-colors duration-200">
                View All Activities
              </button>
            </div>
          </div>
          
          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <h2 className="text-lg font-semibold mb-4 text-gray-800">Quick Actions</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200 text-center">
                <Calendar size={24} className="mx-auto mb-2 text-primary-500" />
                <span className="text-sm text-gray-700">Add Event</span>
              </button>
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200 text-center">
                <ArchiveRestore size={24} className="mx-auto mb-2 text-secondary-500" />
                <span className="text-sm text-gray-700">New Artifact</span>
              </button>
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200 text-center">
                <ImageIcon size={24} className="mx-auto mb-2 text-accent-500" />
                <span className="text-sm text-gray-700">Upload Images</span>
              </button>
              <button className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200 text-center">
                <Newspaper size={24} className="mx-auto mb-2 text-green-500" />
                <span className="text-sm text-gray-700">Write Article</span>
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default Dashboard;