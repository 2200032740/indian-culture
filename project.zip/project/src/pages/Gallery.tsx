import React, { useState } from 'react';
import HeroSection from '../components/HeroSection';
import GalleryImage from '../components/GalleryImage';

function Gallery() {
  // Sample data
  const allImages = [
    {
      id: 1,
      src: 'https://images.pexels.com/photos/1010518/pexels-photo-1010518.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Traditional Indian Wedding',
      category: 'Festivals'
    },
    {
      id: 2,
      src: 'https://images.pexels.com/photos/5384316/pexels-photo-5384316.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Kathakali Performer',
      category: 'Dance'
    },
    {
      id: 3,
      src: 'https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Taj Mahal',
      category: 'Architecture'
    },
    {
      id: 4,
      src: 'https://images.pexels.com/photos/12671117/pexels-photo-12671117.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Indian Spice Market',
      category: 'Cuisine'
    },
    {
      id: 5,
      src: 'https://images.pexels.com/photos/695779/pexels-photo-695779.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Decorated Elephant for Festival',
      category: 'Festivals'
    },
    {
      id: 6,
      src: 'https://images.pexels.com/photos/16019057/pexels-photo-16019057/free-photo-of-traditional-dancer.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Bharatanatyam Dancer',
      category: 'Dance'
    },
    {
      id: 7,
      src: 'https://images.pexels.com/photos/15999591/pexels-photo-15999591/free-photo-of-sitar-player.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Sitar Player',
      category: 'Music'
    },
    {
      id: 8,
      src: 'https://images.pexels.com/photos/10243724/pexels-photo-10243724.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Traditional Indian Pottery',
      category: 'Crafts'
    },
    {
      id: 9,
      src: 'https://images.pexels.com/photos/3781008/pexels-photo-3781008.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Colorful Holi Festival',
      category: 'Festivals'
    },
    {
      id: 10,
      src: 'https://images.pexels.com/photos/13009437/pexels-photo-13009437.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Rangoli Art',
      category: 'Crafts'
    },
    {
      id: 11,
      src: 'https://images.pexels.com/photos/12565464/pexels-photo-12565464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Golden Temple, Amritsar',
      category: 'Architecture'
    },
    {
      id: 12,
      src: 'https://images.pexels.com/photos/4087418/pexels-photo-4087418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Traditional Indian Thali',
      category: 'Cuisine'
    }
  ];
  
  const categories = ['All', 'Festivals', 'Dance', 'Music', 'Architecture', 'Cuisine', 'Crafts'];
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [filteredImages, setFilteredImages] = useState(allImages);
  
  const filterImages = (category: string) => {
    setSelectedCategory(category);
    if (category === 'All') {
      setFilteredImages(allImages);
    } else {
      setFilteredImages(allImages.filter(image => image.category === category));
    }
  };
  
  return (
    <div>
      <HeroSection
        title="Cultural Gallery"
        subtitle="Visual journey through India's cultural richness"
        imageSrc="https://images.pexels.com/photos/7772997/pexels-photo-7772997.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Explore Our Gallery</h2>
            <p className="text-gray-600">
              Browse through our collection of images capturing the essence of Indian culture,
              from traditional arts and ceremonies to architectural marvels and daily life.
            </p>
          </div>
          
          <div className="flex justify-center flex-wrap gap-2 mb-10">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => filterImages(category)}
                className={`
                  px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200
                  ${selectedCategory === category 
                    ? 'bg-primary-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}
                `}
              >
                {category}
              </button>
            ))}
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredImages.map((image) => (
              <GalleryImage key={image.id} {...image} />
            ))}
          </div>
          
          {filteredImages.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-600">No images found in this category.</p>
            </div>
          )}
        </div>
      </section>
      
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Share Your Cultural Moments</h2>
            <p className="text-gray-600 mb-6">
              Have you captured a beautiful moment of Indian culture? Share your photographs with us and 
              contribute to our growing gallery of cultural treasures.
            </p>
            <button className="inline-block px-6 py-3 bg-accent-500 text-white rounded-md hover:bg-accent-600 transition-colors duration-200">
              Submit Your Photos
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Gallery;