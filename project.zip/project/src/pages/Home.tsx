import React from 'react';
import HeroSection from '../components/HeroSection';
import EventCard from '../components/EventCard';
import ArtifactCard from '../components/ArtifactCard';
import GalleryImage from '../components/GalleryImage';
import NewsCard from '../components/NewsCard';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

function Home() {
  // Sample data
  const events = [
    {
      id: 1,
      title: 'Diwali Festival Celebration',
      description: 'Join us for a grand celebration of the Festival of Lights with traditional performances, food, and activities.',
      date: 'October 24, 2025',
      time: '5:00 PM - 10:00 PM',
      location: 'Cultural Center, New Delhi',
      imageSrc: 'https://images.pexels.com/photos/2693529/pexels-photo-2693529.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: true
    },
    {
      id: 2,
      title: 'Classical Dance Workshop',
      description: 'Learn the basics of Bharatanatyam from renowned dancer Padma Subramaniam.',
      date: 'September 15, 2025',
      time: '10:00 AM - 1:00 PM',
      location: 'Dance Academy, Mumbai',
      imageSrc: 'https://images.pexels.com/photos/3226806/pexels-photo-3226806.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 3,
      title: 'Indian Classical Music Concert',
      description: 'A mesmerizing evening of Carnatic and Hindustani classical music performances.',
      date: 'September 30, 2025',
      time: '7:00 PM - 9:00 PM',
      location: 'Music Hall, Bangalore',
      imageSrc: 'https://images.pexels.com/photos/2694443/pexels-photo-2694443.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ];
  
  const artifacts = [
    {
      id: 1,
      title: 'Bronze Nataraja Statue',
      description: 'This exquisite bronze statue depicts Lord Shiva as the cosmic dancer, symbolizing the cycle of creation and destruction.',
      origin: 'Tamil Nadu',
      period: '12th Century CE',
      imageSrc: 'https://images.pexels.com/photos/11101599/pexels-photo-11101599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 2,
      title: 'Mughal Miniature Painting',
      description: 'A detailed miniature painting from the Mughal era depicting a royal court scene with intricate details.',
      origin: 'Northern India',
      period: '17th Century CE',
      imageSrc: 'https://images.pexels.com/photos/6507483/pexels-photo-6507483.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 3,
      title: 'Ancient Sanskrit Manuscript',
      description: 'A preserved palm leaf manuscript containing verses from ancient Sanskrit texts with beautiful calligraphy.',
      origin: 'Kerala',
      period: '9th Century CE',
      imageSrc: 'https://images.pexels.com/photos/4550784/pexels-photo-4550784.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 4,
      title: 'Ajanta Cave Painting Replica',
      description: 'A faithful replica of the famous Buddhist paintings from the Ajanta Caves, showcasing the ancient art style.',
      origin: 'Maharashtra',
      period: '5th Century CE (Original)',
      imageSrc: 'https://images.pexels.com/photos/12436272/pexels-photo-12436272.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ];
  
  const galleryImages = [
    {
      id: 1,
      src: 'https://images.pexels.com/photos/1010518/pexels-photo-1010518.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Traditional Indian Wedding',
      category: 'Festivals'
    },
    {
      id: 2,
      src: 'https://images.pexels.com/photos/5384316/pexels-photo-5384316.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Kathakali Performer',
      category: 'Dance'
    },
    {
      id: 3,
      src: 'https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Taj Mahal',
      category: 'Architecture'
    },
    {
      id: 4,
      src: 'https://images.pexels.com/photos/12671117/pexels-photo-12671117.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Indian Spice Market',
      category: 'Cuisine'
    }
  ];
  
  const news = [
    {
      id: 1,
      title: 'Ministry of Culture Announces New Initiative to Preserve Tribal Art Forms',
      summary: 'The Indian Ministry of Culture has launched a new nationwide program to document, preserve, and promote tribal art forms that are at risk of being lost. The initiative will provide funding for research, workshops, and exhibitions.',
      date: 'August 25, 2025',
      author: 'Rajiv Sharma',
      imageSrc: 'https://images.pexels.com/photos/5619913/pexels-photo-5619913.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: true
    },
    {
      id: 2,
      title: 'International Recognition for Indian Classical Dance Documentary',
      summary: 'A documentary about the evolution of Bharatanatyam has won the Best Documentary Award at the International Film Festival in Toronto.',
      date: 'August 10, 2025',
      author: 'Priya Nair',
      imageSrc: 'https://images.pexels.com/photos/5582867/pexels-photo-5582867.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ];
  
  return (
    <div>
      <HeroSection
        title="Preserving India's Rich Cultural Heritage"
        subtitle="Discover, Experience, and Celebrate the Diverse Traditions of India"
        imageSrc="https://images.pexels.com/photos/5393401/pexels-photo-5393401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
        height="xl"
      >
        <div className="flex flex-col sm:flex-row gap-4 mt-2 justify-center">
          <Link
            to="/events"
            className="px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-md transition-colors duration-200 font-medium"
          >
            Explore Events
          </Link>
          <Link
            to="/gallery"
            className="px-6 py-3 bg-white hover:bg-gray-100 text-primary-700 rounded-md transition-colors duration-200 font-medium"
          >
            Browse Gallery
          </Link>
        </div>
      </HeroSection>
      
      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">About Our Mission</h2>
            <p className="text-gray-600">
              The Indian Cultural Management System is dedicated to preserving, promoting, and celebrating 
              the rich and diverse cultural heritage of India. Our platform serves as a comprehensive 
              resource for cultural events, artifacts, galleries, and educational content that showcases 
              the beauty and depth of Indian traditions.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center p-6 bg-primary-50 rounded-lg">
              <div className="bg-primary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary-600">
                  <path d="M3 6v18h18V6"></path>
                  <path d="M3 6V3a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v3"></path>
                  <path d="M3 13h18"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Preserve</h3>
              <p className="text-gray-600">
                We document and digitize cultural artifacts, traditions, and knowledge to ensure they are preserved for future generations.
              </p>
            </div>
            
            <div className="text-center p-6 bg-secondary-50 rounded-lg">
              <div className="bg-secondary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-secondary-600">
                  <path d="M12 5.5v13"></path>
                  <path d="M5.5 12h13"></path>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Promote</h3>
              <p className="text-gray-600">
                We create platforms and opportunities for artists, performers, and cultural practitioners to showcase their talents.
              </p>
            </div>
            
            <div className="text-center p-6 bg-accent-50 rounded-lg">
              <div className="bg-accent-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent-500">
                  <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                  <polyline points="13 2 13 9 20 9"></polyline>
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Educate</h3>
              <p className="text-gray-600">
                We provide educational resources and programs to help people understand and appreciate the depth of Indian culture.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Upcoming Events Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800">Upcoming Events</h2>
            <Link to="/events" className="text-primary-600 hover:text-primary-800 flex items-center">
              <span>View All Events</span>
              <ArrowRight size={18} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            {events.map((event) => (
              <EventCard key={event.id} {...event} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Cultural Artifacts Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800">Cultural Artifacts</h2>
            <Link to="/artifacts" className="text-primary-600 hover:text-primary-800 flex items-center">
              <span>Explore Collection</span>
              <ArrowRight size={18} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            {artifacts.map((artifact) => (
              <ArtifactCard key={artifact.id} {...artifact} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Gallery Showcase */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Featured Gallery</h2>
            <Link to="/gallery" className="text-accent-400 hover:text-accent-300 flex items-center">
              <span>Browse Full Gallery</span>
              <ArrowRight size={18} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid md:grid-cols-4 gap-4">
            {galleryImages.map((image) => (
              <GalleryImage key={image.id} {...image} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Latest News */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800">Latest Cultural News</h2>
            <Link to="/news" className="text-primary-600 hover:text-primary-800 flex items-center">
              <span>Read All News</span>
              <ArrowRight size={18} className="ml-1" />
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            {news.map((item) => (
              <NewsCard key={item.id} {...item} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Call to Action */}
      <section className="py-16 bg-primary-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Cultural Community</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            Be a part of our mission to preserve and promote Indian cultural heritage. Register for events, contribute to our collection, or volunteer your time.
          </p>
          <Link 
            to="/contact" 
            className="inline-block px-8 py-4 bg-white text-primary-800 rounded-md hover:bg-gray-100 transition-colors duration-200 font-medium"
          >
            Get Involved
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Home;