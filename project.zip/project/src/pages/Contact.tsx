import React from 'react';
import HeroSection from '../components/HeroSection';
import ContactForm from '../components/ContactForm';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

function Contact() {
  return (
    <div>
      <HeroSection
        title="Contact Us"
        subtitle="Get in touch with our team for inquiries, partnerships, or support"
        imageSrc="https://images.pexels.com/photos/7245326/pexels-photo-7245326.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
        height="md"
      />
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">How Can We Help You?</h2>
            <p className="text-gray-600">
              Whether you have questions about our programs, want to support our mission, or need information about 
              Indian cultural topics, we're here to assist you. Please fill out the form below or use our contact 
              information to reach us directly.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="bg-primary-100 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Call Us</h3>
              <p className="text-gray-600">+91 98765 43210</p>
              <p className="text-gray-600">+91 11 2345 6789</p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="bg-primary-100 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Email Us</h3>
              <p className="text-gray-600">contact@indianculture.org</p>
              <p className="text-gray-600">info@indianculture.org</p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <div className="bg-primary-100 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-primary-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-gray-800">Office Hours</h3>
              <p className="text-gray-600">Monday - Friday: 9:00 AM - 5:00 PM</p>
              <p className="text-gray-600">Saturday: 10:00 AM - 2:00 PM</p>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Send Us a Message</h3>
              <ContactForm />
            </div>
            
            <div>
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Visit Our Office</h3>
              <div className="bg-gray-100 rounded-lg overflow-hidden h-64 mb-6">
                {/* This would be replaced with an actual map integration */}
                <div className="w-full h-full bg-gray-300 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin size={32} className="mx-auto mb-2 text-gray-600" />
                    <p className="text-gray-700 font-medium">Interactive Map Placeholder</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="font-semibold text-gray-800 mb-3">Our Location</h4>
                <p className="text-gray-600 mb-4">
                  123 Cultural Heritage Road<br />
                  New Delhi, 110001<br />
                  India
                </p>
                
                <h4 className="font-semibold text-gray-800 mb-3">Getting Here</h4>
                <p className="text-gray-600">
                  We are located near the India Gate, easily accessible by metro (Central Secretariat station) 
                  or by bus. Parking is available in the building basement.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
            <div className="mt-8 space-y-4">
              <div className="bg-white p-5 rounded-lg shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-2">How can I get involved with your cultural programs?</h3>
                <p className="text-gray-600">
                  There are many ways to get involved! You can volunteer for events, submit proposals for cultural initiatives, 
                  or become a member to receive regular updates and invitations.
                </p>
              </div>
              
              <div className="bg-white p-5 rounded-lg shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-2">Do you offer educational resources for schools?</h3>
                <p className="text-gray-600">
                  Yes, we provide curriculum materials, workshop packages, and virtual tours tailored for different educational levels. 
                  Please contact our education team for details.
                </p>
              </div>
              
              <div className="bg-white p-5 rounded-lg shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-2">How can I propose a cultural event?</h3>
                <p className="text-gray-600">
                  We welcome event proposals! Please submit your idea through our contact form, including details about the event, 
                  its cultural significance, and your contact information.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;