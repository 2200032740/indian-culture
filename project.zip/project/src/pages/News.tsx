import React, { useState } from 'react';
import HeroSection from '../components/HeroSection';
import NewsCard from '../components/NewsCard';
import SearchBar from '../components/SearchBar';

function News() {
  // Sample data
  const allNews = [
    {
      id: 1,
      title: 'Ministry of Culture Announces New Initiative to Preserve Tribal Art Forms',
      summary: 'The Indian Ministry of Culture has launched a new nationwide program to document, preserve, and promote tribal art forms that are at risk of being lost. The initiative will provide funding for research, workshops, and exhibitions.',
      date: 'August 25, 2025',
      author: 'Rajiv Sharma',
      imageSrc: 'https://images.pexels.com/photos/5619913/pexels-photo-5619913.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: true,
      category: 'Policy'
    },
    {
      id: 2,
      title: 'International Recognition for Indian Classical Dance Documentary',
      summary: 'A documentary about the evolution of Bharatanatyam has won the Best Documentary Award at the International Film Festival in Toronto.',
      date: 'August 10, 2025',
      author: 'Priya Nair',
      imageSrc: 'https://images.pexels.com/photos/5582867/pexels-photo-5582867.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Awards'
    },
    {
      id: 3,
      title: 'Digital Archive of Sanskrit Manuscripts Now Available Online',
      summary: 'A collaborative project between universities and cultural institutions has resulted in a comprehensive digital archive of rare Sanskrit manuscripts, making them accessible to researchers worldwide.',
      date: 'July 30, 2025',
      author: 'Anil Gupta',
      imageSrc: 'https://images.pexels.com/photos/3368816/pexels-photo-3368816.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Research'
    },
    {
      id: 4,
      title: 'National Crafts Fair to Showcase Regional Artisans',
      summary: 'The annual National Crafts Fair will be held next month in Delhi, featuring over 500 artisans from across India showcasing traditional crafts and techniques.',
      date: 'July 25, 2025',
      author: 'Meera Patel',
      imageSrc: 'https://images.pexels.com/photos/2923146/pexels-photo-2923146.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Events'
    },
    {
      id: 5,
      title: 'Archaeological Survey Discovers Ancient Temple Complex in Tamil Nadu',
      summary: 'Archaeologists have uncovered a previously unknown temple complex dating back to the 9th century in southern Tamil Nadu, with unique architectural features and inscriptions.',
      date: 'July 15, 2025',
      author: 'Dr. Sundar Rajan',
      imageSrc: 'https://images.pexels.com/photos/5067895/pexels-photo-5067895.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Research'
    },
    {
      id: 6,
      title: 'UNESCO Adds Indian Classical Music Tradition to Intangible Cultural Heritage List',
      summary: 'UNESCO has officially recognized the tradition of Dhrupad, one of the oldest forms of Indian classical music, as an Intangible Cultural Heritage of Humanity.',
      date: 'July 5, 2025',
      author: 'Lakshmi Venkatesh',
      imageSrc: 'https://images.pexels.com/photos/3784566/pexels-photo-3784566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Recognition'
    }
  ];
  
  const [filteredNews, setFilteredNews] = useState(allNews);
  const newsCategories = ['Policy', 'Events', 'Awards', 'Research', 'Recognition'];
  
  const handleSearch = (query: string, category: string) => {
    let results = allNews;
    
    if (query) {
      const searchTerm = query.toLowerCase();
      results = results.filter(news => 
        news.title.toLowerCase().includes(searchTerm) || 
        news.summary.toLowerCase().includes(searchTerm) ||
        news.author.toLowerCase().includes(searchTerm)
      );
    }
    
    if (category && category !== 'all') {
      results = results.filter(news => news.category === category);
    }
    
    setFilteredNews(results);
  };
  
  return (
    <div>
      <HeroSection
        title="Cultural News & Updates"
        subtitle="Stay informed about the latest developments in Indian cultural sphere"
        imageSrc="https://images.pexels.com/photos/518543/pexels-photo-518543.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <SearchBar 
            placeholder="Search news articles..." 
            categories={newsCategories}
            onSearch={handleSearch}
          />
          
          <div className="mt-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Latest News</h2>
            
            {filteredNews.length === 0 ? (
              <div className="bg-gray-50 p-8 rounded-lg text-center">
                <h3 className="text-xl font-medium text-gray-700 mb-2">No news articles found</h3>
                <p className="text-gray-600">Try adjusting your search criteria.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-8">
                {filteredNews.map((article) => (
                  <NewsCard key={article.id} {...article} />
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
      
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Subscribe to Our Newsletter</h2>
              <p className="text-gray-600 mb-6">
                Stay updated with the latest news and events from the world of Indian culture. 
                Our newsletter is sent monthly and includes exclusive content and early announcements.
              </p>
              
              <form className="flex flex-col sm:flex-row gap-3">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex-grow px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  required
                />
                <button 
                  type="submit" 
                  className="px-6 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors duration-200"
                >
                  Subscribe
                </button>
              </form>
              
              <p className="text-xs text-gray-500 mt-4">
                By subscribing, you agree to receive email communications from us. 
                You can unsubscribe at any time.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default News;