import React, { useState } from 'react';
import HeroSection from '../components/HeroSection';
import EventCard from '../components/EventCard';
import SearchBar from '../components/SearchBar';

function Events() {
  // Sample data
  const allEvents = [
    {
      id: 1,
      title: 'Diwali Festival Celebration',
      description: 'Join us for a grand celebration of the Festival of Lights with traditional performances, food, and activities.',
      date: 'October 24, 2025',
      time: '5:00 PM - 10:00 PM',
      location: 'Cultural Center, New Delhi',
      imageSrc: 'https://images.pexels.com/photos/2693529/pexels-photo-2693529.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      featured: true,
      category: 'Festival'
    },
    {
      id: 2,
      title: 'Classical Dance Workshop',
      description: 'Learn the basics of Bharatanatyam from renowned dancer Padma Subramaniam.',
      date: 'September 15, 2025',
      time: '10:00 AM - 1:00 PM',
      location: 'Dance Academy, Mumbai',
      imageSrc: 'https://images.pexels.com/photos/3226806/pexels-photo-3226806.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Workshop'
    },
    {
      id: 3,
      title: 'Indian Classical Music Concert',
      description: 'A mesmerizing evening of Carnatic and Hindustani classical music performances.',
      date: 'September 30, 2025',
      time: '7:00 PM - 9:00 PM',
      location: 'Music Hall, Bangalore',
      imageSrc: 'https://images.pexels.com/photos/2694443/pexels-photo-2694443.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Concert'
    },
    {
      id: 4,
      title: 'Handicraft Exhibition',
      description: 'Explore the rich tradition of Indian handicrafts with artisans from across the country showcasing their work.',
      date: 'October 5-10, 2025',
      time: '11:00 AM - 8:00 PM',
      location: 'Exhibition Center, Jaipur',
      imageSrc: 'https://images.pexels.com/photos/6195663/pexels-photo-6195663.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Exhibition'
    },
    {
      id: 5,
      title: 'Yoga and Meditation Retreat',
      description: 'A weekend of rejuvenation with traditional yoga and meditation practices guided by expert practitioners.',
      date: 'September 24-26, 2025',
      time: 'All Day',
      location: 'Spiritual Center, Rishikesh',
      imageSrc: 'https://images.pexels.com/photos/8436727/pexels-photo-8436727.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Retreat'
    },
    {
      id: 6,
      title: 'Culinary Workshop: Regional Indian Cuisine',
      description: 'Learn to prepare authentic dishes from various Indian regions with master chefs.',
      date: 'October 15, 2025',
      time: '2:00 PM - 5:00 PM',
      location: 'Culinary Institute, Chennai',
      imageSrc: 'https://images.pexels.com/photos/2474661/pexels-photo-2474661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Workshop'
    },
    {
      id: 7,
      title: 'Film Festival: Celebrating Indian Cinema',
      description: 'A week-long festival showcasing classic and contemporary Indian films from various regions and languages.',
      date: 'October 1-7, 2025',
      time: 'Various Timings',
      location: 'City Film Center, Mumbai',
      imageSrc: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Festival'
    },
    {
      id: 8,
      title: 'Literary Symposium: Indian Literature Through Ages',
      description: 'A gathering of authors, poets, and literary scholars discussing the evolution of Indian literature.',
      date: 'September 20, 2025',
      time: '10:00 AM - 4:00 PM',
      location: 'University Auditorium, Delhi',
      imageSrc: 'https://images.pexels.com/photos/159866/books-book-pages-read-literature-159866.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Symposium'
    }
  ];
  
  const [filteredEvents, setFilteredEvents] = useState(allEvents);
  const eventCategories = ['Festival', 'Workshop', 'Concert', 'Exhibition', 'Retreat', 'Symposium'];
  
  const handleSearch = (query: string, category: string) => {
    let results = allEvents;
    
    if (query) {
      const searchTerm = query.toLowerCase();
      results = results.filter(event => 
        event.title.toLowerCase().includes(searchTerm) || 
        event.description.toLowerCase().includes(searchTerm) ||
        event.location.toLowerCase().includes(searchTerm)
      );
    }
    
    if (category && category !== 'all') {
      results = results.filter(event => event.category === category);
    }
    
    setFilteredEvents(results);
  };
  
  return (
    <div>
      <HeroSection
        title="Cultural Events & Programs"
        subtitle="Discover and participate in a variety of events celebrating Indian culture"
        imageSrc="https://images.pexels.com/photos/8224957/pexels-photo-8224957.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <SearchBar 
            placeholder="Search for events..." 
            categories={eventCategories}
            onSearch={handleSearch}
          />
          
          <div className="mt-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Upcoming Events</h2>
            
            {filteredEvents.length === 0 ? (
              <div className="bg-gray-50 p-8 rounded-lg text-center">
                <h3 className="text-xl font-medium text-gray-700 mb-2">No events found</h3>
                <p className="text-gray-600">Try adjusting your search criteria or check back later for new events.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredEvents.map((event) => (
                  <EventCard key={event.id} {...event} />
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
      
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Want to host a cultural event?</h2>
          <p className="text-gray-600 mb-8">
            We provide a platform for individuals and organizations to host and promote cultural events. 
            If you're interested in organizing an event, get in touch with us!
          </p>
          <button className="inline-block px-6 py-3 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors duration-200">
            Propose an Event
          </button>
        </div>
      </section>
    </div>
  );
}

export default Events;