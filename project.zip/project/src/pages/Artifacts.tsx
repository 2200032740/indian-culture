import React, { useState } from 'react';
import HeroSection from '../components/HeroSection';
import ArtifactCard from '../components/ArtifactCard';
import SearchBar from '../components/SearchBar';

function Artifacts() {
  // Sample data
  const allArtifacts = [
    {
      id: 1,
      title: 'Bronze Nataraja Statue',
      description: 'This exquisite bronze statue depicts Lord Shiva as the cosmic dancer, symbolizing the cycle of creation and destruction.',
      origin: 'Tamil Nadu',
      period: '12th Century CE',
      imageSrc: 'https://images.pexels.com/photos/11101599/pexels-photo-11101599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Sculpture'
    },
    {
      id: 2,
      title: 'Mughal Miniature Painting',
      description: 'A detailed miniature painting from the Mughal era depicting a royal court scene with intricate details.',
      origin: 'Northern India',
      period: '17th Century CE',
      imageSrc: 'https://images.pexels.com/photos/6507483/pexels-photo-6507483.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Painting'
    },
    {
      id: 3,
      title: 'Ancient Sanskrit Manuscript',
      description: 'A preserved palm leaf manuscript containing verses from ancient Sanskrit texts with beautiful calligraphy.',
      origin: 'Kerala',
      period: '9th Century CE',
      imageSrc: 'https://images.pexels.com/photos/4550784/pexels-photo-4550784.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Manuscript'
    },
    {
      id: 4,
      title: 'Ajanta Cave Painting Replica',
      description: 'A faithful replica of the famous Buddhist paintings from the Ajanta Caves, showcasing the ancient art style.',
      origin: 'Maharashtra',
      period: '5th Century CE (Original)',
      imageSrc: 'https://images.pexels.com/photos/12436272/pexels-photo-12436272.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Painting'
    },
    {
      id: 5,
      title: 'Banaras Silk Saree',
      description: 'A handwoven silk saree from Varanasi with intricate gold thread work showcasing traditional motifs.',
      origin: 'Uttar Pradesh',
      period: 'Contemporary (Traditional Style)',
      imageSrc: 'https://images.pexels.com/photos/11744302/pexels-photo-11744302.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Textile'
    },
    {
      id: 6,
      title: 'Bidri Ware Vase',
      description: 'A metal vase created using the ancient Bidri technique, with silver inlay work on a blackened zinc and copper alloy.',
      origin: 'Karnataka',
      period: '19th Century CE',
      imageSrc: 'https://images.pexels.com/photos/6207355/pexels-photo-6207355.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Metalwork'
    },
    {
      id: 7,
      title: 'Traditional Kathputli Puppet',
      description: 'A colorful string puppet from Rajasthan used in traditional storytelling and folk performances.',
      origin: 'Rajasthan',
      period: 'Early 20th Century',
      imageSrc: 'https://images.pexels.com/photos/14799767/pexels-photo-14799767.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Folk Art'
    },
    {
      id: 8,
      title: 'Carved Wooden Temple Chariot',
      description: 'A miniature replica of a temple chariot (ratha) with intricate wooden carvings depicting mythological scenes.',
      origin: 'Tamil Nadu',
      period: 'Late 19th Century',
      imageSrc: 'https://images.pexels.com/photos/8266804/pexels-photo-8266804.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      category: 'Woodwork'
    }
  ];
  
  const [filteredArtifacts, setFilteredArtifacts] = useState(allArtifacts);
  const artifactCategories = ['Sculpture', 'Painting', 'Manuscript', 'Textile', 'Metalwork', 'Folk Art', 'Woodwork'];
  
  const handleSearch = (query: string, category: string) => {
    let results = allArtifacts;
    
    if (query) {
      const searchTerm = query.toLowerCase();
      results = results.filter(artifact => 
        artifact.title.toLowerCase().includes(searchTerm) || 
        artifact.description.toLowerCase().includes(searchTerm) ||
        artifact.origin.toLowerCase().includes(searchTerm) ||
        artifact.period.toLowerCase().includes(searchTerm)
      );
    }
    
    if (category && category !== 'all') {
      results = results.filter(artifact => artifact.category === category);
    }
    
    setFilteredArtifacts(results);
  };
  
  return (
    <div>
      <HeroSection
        title="Cultural Artifacts Collection"
        subtitle="Discover the treasures of Indian cultural heritage"
        imageSrc="https://images.pexels.com/photos/7887775/pexels-photo-7887775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Explore Our Artifact Collection</h2>
            <p className="text-gray-600">
              Our collection features a wide range of artifacts representing the diversity of Indian cultural heritage.
              From ancient sculptures to traditional textiles, each piece tells a story of India's rich history and artistic traditions.
            </p>
          </div>
          
          <SearchBar 
            placeholder="Search artifacts..." 
            categories={artifactCategories}
            onSearch={handleSearch}
          />
          
          <div className="mt-12">
            {filteredArtifacts.length === 0 ? (
              <div className="bg-gray-50 p-8 rounded-lg text-center">
                <h3 className="text-xl font-medium text-gray-700 mb-2">No artifacts found</h3>
                <p className="text-gray-600">Try adjusting your search criteria.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {filteredArtifacts.map((artifact) => (
                  <ArtifactCard key={artifact.id} {...artifact} />
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Artifact Preservation Initiative</h2>
              <p className="text-gray-600 mb-6">
                Our organization is committed to the preservation and documentation of cultural artifacts from across India. 
                We work with museums, private collectors, and cultural institutions to ensure these treasures are properly preserved for future generations.
              </p>
              
              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="font-semibold text-gray-800 mb-2">Documentation</h3>
                  <p className="text-sm text-gray-600">
                    We create detailed records of artifacts including their history, significance, and condition.
                  </p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="font-semibold text-gray-800 mb-2">Conservation</h3>
                  <p className="text-sm text-gray-600">
                    We employ expert conservationists to ensure artifacts are properly maintained and restored when necessary.
                  </p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-md">
                  <h3 className="font-semibold text-gray-800 mb-2">Education</h3>
                  <p className="text-sm text-gray-600">
                    We develop educational programs to help people understand the cultural significance of these artifacts.
                  </p>
                </div>
              </div>
              
              <button className="inline-block px-6 py-3 bg-secondary-600 text-white rounded-md hover:bg-secondary-700 transition-colors duration-200">
                Learn More About Preservation
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Artifacts;