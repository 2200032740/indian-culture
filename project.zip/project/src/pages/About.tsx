import React from 'react';
import HeroSection from '../components/HeroSection';
import { Smile, Award, Users, Heart } from 'lucide-react';

function About() {
  const teamMembers = [
    {
      name: 'Dr. Rajesh Kumar',
      position: 'Director',
      bio: 'Dr. Kumar has over 20 years of experience in cultural preservation and has published extensively on Indian performing arts.',
      imageSrc: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      name: 'Priya Sharma',
      position: 'Curator, Artifacts Division',
      bio: 'Priya specializes in ancient Indian sculptures and has led several restoration projects across major museums.',
      imageSrc: 'https://images.pexels.com/photos/1181690/pexels-photo-1181690.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      name: 'Amit Patel',
      position: 'Events Coordinator',
      bio: 'Amit has organized over 100 cultural events and specializes in creating immersive experiences for audiences.',
      imageSrc: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      name: 'Lakshmi Nair',
      position: 'Education Specialist',
      bio: 'Lakshmi develops educational programs that help young people connect with their cultural heritage.',
      imageSrc: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ];
  
  return (
    <div>
      <HeroSection
        title="About Our Mission"
        subtitle="Preserving and celebrating the rich cultural heritage of India"
        imageSrc="https://images.pexels.com/photos/4101555/pexels-photo-4101555.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
      />
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Our Story</h2>
            <div className="prose prose-lg">
              <p>
                The Indian Cultural Management System was established in 2020 with a vision to create a comprehensive 
                platform for preserving, documenting, and promoting the diverse cultural heritage of India. 
                What began as a small initiative by a group of cultural enthusiasts has grown into a nationwide 
                organization dedicated to ensuring that India's rich traditions continue to thrive in the digital age.
              </p>
              <p>
                Our organization brings together experts from various fields – historians, artists, technologists, 
                educators, and community leaders – all united by a common passion for Indian culture. We work 
                closely with government institutions, museums, artists, researchers, and communities across 
                the country to create a living archive of cultural knowledge and practices.
              </p>
              <p>
                Through our digital platform, events, educational programs, and preservation initiatives, 
                we aim to make India's cultural heritage accessible to everyone while ensuring its 
                authenticity and significance are maintained for future generations.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-800 mb-12 text-center">Our Core Values</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="bg-primary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Smile size={32} className="text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Authenticity</h3>
              <p className="text-gray-600">
                We are committed to presenting cultural traditions with accuracy and respect for their historical context.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="bg-secondary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award size={32} className="text-secondary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Excellence</h3>
              <p className="text-gray-600">
                We strive for the highest quality in all our initiatives, exhibitions, and educational programs.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="bg-accent-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users size={32} className="text-accent-500" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Inclusivity</h3>
              <p className="text-gray-600">
                We celebrate India's cultural diversity and ensure representation from all regions and traditions.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart size={32} className="text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Preservation</h3>
              <p className="text-gray-600">
                We are dedicated to safeguarding cultural heritage for future generations through documentation and education.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-800 mb-12 text-center">Our Team</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                <div className="h-64 overflow-hidden">
                  <img 
                    src={member.imageSrc} 
                    alt={member.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-5">
                  <h3 className="text-xl font-semibold mb-1 text-gray-800">{member.name}</h3>
                  <p className="text-primary-600 font-medium mb-3">{member.position}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Our Partners & Collaborators</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">Ministry of Culture</p>
              </div>
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">National Museum</p>
              </div>
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">Sangeet Natak Akademi</p>
              </div>
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">Archaeological Survey</p>
              </div>
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">Digital India Foundation</p>
              </div>
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">INTACH</p>
              </div>
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">UNESCO India</p>
              </div>
              <div className="bg-white p-4 rounded-lg flex items-center justify-center h-24 shadow-sm">
                <p className="font-medium text-gray-700">Cultural Universities Alliance</p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-primary-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Join Our Mission</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            We're always looking for passionate individuals and organizations to join our mission of preserving 
            and promoting Indian cultural heritage. Whether you're an artist, researcher, educator, or enthusiast, 
            there's a place for you in our community.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-6 py-3 bg-white text-primary-800 rounded-md hover:bg-gray-100 transition-colors duration-200">
              Volunteer With Us
            </button>
            <button className="px-6 py-3 border-2 border-white text-white rounded-md hover:bg-white/10 transition-colors duration-200">
              Partnership Opportunities
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;